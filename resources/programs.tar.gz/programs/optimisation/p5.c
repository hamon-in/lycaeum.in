#include <stdio.h>
#include <stdlib.h>

int isprime(int);

int isprime(int n)
{
  int i;
  if (n % 2 == 0)
    return (n == 2);
  if (n % 3 == 0)
    return (n == 3);
  if (n % 5 == 0)
    return (n == 5);

  for (i = 7; i*i <= n; i+=2)
    if (n % i == 0)
      return 0;
  return 1;
}


int main(int argc, char **argv)
{
  int i, n;
  if (argc != 2) {
    printf("Error: No limit specified\nUsage: %s <limit>\nWhere <limit> is the number upto which you want to print primes.\n", argv[0]);
    return -1;
  }
  n = atoi(argv[1]);

  for (i = 2; i <= n; i++)
    if (isprime(i))
      printf("%d\n", i);
  return 0;
}
  

  

