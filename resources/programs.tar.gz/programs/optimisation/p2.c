#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int isprime(int);

float root(double);

float
root(double n)
{
  double x = 0.0;
  double xn = 0.0;
  int iters = 0;
  int i;
  for (i = 0; i <= (int)n; ++i)
    {
      double val = i*i-n;
      if (val == 0.0)
        return i;
      if (val > 0.0)
        {
          xn = (i+(i-1))/2.0;
          break;
        }
    }
  while (!(iters++ >= 100 || x == xn ))
    {
      x = xn;
      xn = x - (x * x - n) / (2 * x);
    }

  return xn;
}

int
isprime(int n)
{
  int i;
  for (i = 2; i <= root((double)n); i++)
    if (n % i == 0)
      return 0;
  return 1;
}


int
main(int argc, char **argv)
{
  int i, n;
  if (argc != 2) {
    printf("Error: No limit specified\nUsage: %s <limit>\nWhere <limit> is the number upto which you want to print primes.\n", argv[0]);
    return -1;
  }
  n = atoi(argv[1]);

  for (i = 2; i <= n; i++)
    if (isprime(i))
      ;/* printf("%d\n", i); */
  return 0;
}
  

  

