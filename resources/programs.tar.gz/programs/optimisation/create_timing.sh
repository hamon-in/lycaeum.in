#!/bin/sh

FILES="p1 p2 p3 p4 p5"
COUNTS="100 1000 10000 100000 500000 1000000 5000000 10000000"
MAXTIME="2m" # Change this if you to give the programs more time to
# run. Currently, it's 2 minutes max.
OPFILE="timings"

echo "Running all programs multiple times with a maximum limit of ${MAXTIME} and outputting timing information in ${OPFILE}"

for f in $FILES 
do
    if [ ! -x $f ]; then
        echo "$f not present. Cannot run. Please make sure that all files are compiled before you run this program."
        exit 1;
    fi
done

echo > $OPFILE

for f in $FILES
do
    echo "# ${f}" >> $OPFILE
    for c in $COUNTS
    do
        printf "Running %9d iterations for %s" ${c} ${f}
        /usr/bin/time -f%e timeout ${MAXTIME} ./${f} ${c} > /dev/null 2> /tmp/t
        echo "  Done"
        time=$(cat /tmp/t)
        rm /tmp/t
        echo "${c} ${time}" >> $OPFILE
    done
    echo "\n"
    echo "\n\n" >> $OPFILE
done



