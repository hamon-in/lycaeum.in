This directory contains all the example code used in the "Programming
as Engineering" workshop.

In each directory, there will be a README.html which you can open in
your browser. It contains information on how to use the files in that
directory.

Each directory will also contain a homework.txt file which is the
homework that was mentioned during the presentation. Please try them
out and post them back to the mailing list.

Feedback and corrections are, as always, welcome. You'll be credited
for them in the material.

Thanks!

--
http://thelycaeum.in
noufal@thelycaeum.in
