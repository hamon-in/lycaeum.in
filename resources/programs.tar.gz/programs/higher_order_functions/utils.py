def memoise(original_function):
    cache = {}

    def memoised_function(n):
        if n in cache:
            return cache[n]
        else:
            r = original_function(n)
            cache[n] = r
            return r

    return memoised_function


def trace(original_function):
    original_function.indent = 1

    def traced_function(n):
        # This will replace the original function
        print " "*original_function.indent, "|______%s(%d)"%(original_function.__name__,n)
        original_function.indent += 3
        retval = original_function(n)
        original_function.indent -= 3
        return retval

    return traced_function
