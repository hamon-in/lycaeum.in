def fib(n):
    if n == 0: 
        return 0
    if n == 1:
        return 1
    return fib(n-1) + fib(n-2)

cache = {}
def mem_fib(n):
    if n in cache:
        return cache[n]
    if n == 0: 
        return 0
    if n == 1:
        return 1
    retval = mem_fib(n-1) + mem_fib(n-2)
    cache[n] = retval
    return retval    

def traced_fib(n, indent = 1):
    print " "*indent, "|______fib(%d)"%n
    if n == 0:
        return 0
    if n == 1:
        return 1
    return traced_fib(n-1, indent+3) + traced_fib(n-2, indent+3)
