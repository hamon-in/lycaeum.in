#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

const int MAX_NOS = 10000000;

int 
cmp(const void *a, const void *b)
{
  int x = *(int *)a;
  int y = *(int *)b;
  
  if (x<y) 
    return -1;
  if (x>y)
    return 1;
  return 0;
}

int 
main()
{
  int *nos;
  FILE *fp;
  int n;
  int i = 0;
  
  nos = (int *)malloc(sizeof(int) * MAX_NOS); /*MAX_NOS is 10,000,000*/
  bzero(nos, sizeof(int) * MAX_NOS);
  
  fp = fopen("input.list", "r");
  while (fscanf(fp, "%d\n", &n) != EOF) {
    nos[i++] = n;
  }
  printf("Loaded %d integers\n", i);

  qsort(nos, i, sizeof(int), &cmp);

  /* for (n = 0; n < i; n++) */
  /*     printf("%d\n", nos[n]); */

  free(nos);
  return 0;
}

