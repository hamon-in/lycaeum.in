#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <assert.h>
#include <math.h>

int SIZE = 10000000/8; /* 10^7 bits*/

void 
raw_display(unsigned char *vector)
{
  unsigned char mask;
  int i,j;
  for (i = SIZE-1; i>=0; i--) {
    /* printf("(%d)",i); */
    for (j = 7; j>=0; j--) {
      mask = 1<<j;
      if (vector[i] & mask)
        printf("1");
      else
        printf("0");
    }
    printf(" ");
  }
  printf("\n");
}


void 
display(unsigned char *vector)
{
  unsigned char mask;
  int i,j;
  int num = 0;
  for (i = SIZE-1; i>=0; i--) {
    for (j = 7; j>=0; j--) {
      mask = 1<<j;
      if (vector[i] & mask)
        printf("%d\n",num);
      num ++;
    }
  }
}


void
set(unsigned char *vector, int number)
{
  int byte;
  int bit;
  assert (number < SIZE * 8); /* The number we set shouldn't be more
                                 than the number of bits */
  byte = (SIZE - 1) - (number / 8);
  bit = 7 - number % 8;
  /* printf("Setting bit %d of byte %d to 1\n", bit, byte); */
  
  vector[byte] = vector[byte] | 1<<bit;
}

void
unset(unsigned char *vector, int number)
{
  int byte;
  int bit;
  assert (number < SIZE * 8); /* The number we set shouldn't be more
                                 than the number of bits */
  byte = (SIZE - 1) - (number / 8);
  bit = 7 - number % 8;
  /* printf("Unsetting bit %d of byte %d to 1\n", bit, byte); */
  
  vector[byte] = vector[byte] & (~(1<<bit));
}


int
main()
{
  unsigned int n;
  FILE *fp;

  unsigned char *vector = (unsigned char *)malloc(SIZE); /* SIZE is int 10,000,000/8 == 10^7/8 bytes */
  bzero(vector, SIZE);

  fp = fopen("input.list", "r");
  while (fscanf(fp, "%d\n", &n) != EOF) {
    set(vector, n);
  }
  fclose(fp);
  /* display(vector); */
  free(vector);
  return 0;
}
